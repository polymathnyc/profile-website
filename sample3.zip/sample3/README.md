# My Portfolio Website

This is the source code for portfolio website template, which showcases your skills, experience and projects.

## Technologies Used:

-   HTML
-   CSS
-   JavaScript
-   Astral by [HTML5 UP](https://html5up.net/) was utilized for the creation of this website. The template is available for personal and commercial use under the CCA 3.0 license (html5up.net/license)
